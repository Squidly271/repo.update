####Community Applications####

A Plugin to keep your docker application lists up to date and easily sort them by category and add them to your running containers
