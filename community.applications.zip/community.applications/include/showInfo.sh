#!/bin/bash

cat "/usr/local/emhttp/state/plugins/community.applications/$1.txt" | tr '[' '<' | tr ']' '>'

